package modelo;
// @author brecinosm
public class main {
    public static void main(String[] args) {    
        from_personas frm = new from_personas();
        frm.show();
        
        
    }
}
